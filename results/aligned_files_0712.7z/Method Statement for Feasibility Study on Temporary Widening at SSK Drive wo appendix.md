# Method Statement for Feasibility Study on Temporary Widening at SSK Drive

## 1. Introduction (Overview of the operation/works)

This method statement outlines the general method for the feasibility study on temporary widening along the SSK Drive (Works Area W8A, W8B) including but not limited to topography survey inspection, survey result recording and inspection records analysis. The content mainly describes the procedure of the abovementioned survey works, as well as instrumentation and equipment required for carrying out the survey works. Risk and safety precautions are also considered. The principle methods as described in the following sections are subject to review during construction and may be amended if required. The Inspection and Test Plan (ITP) is enclosed to ensure all parties involved are fully aware of the work procedure (See Appendix B).

## 2. Scope of Works

The general working procedures outlined in this method statement are applicable to the following scopes of work:
- Topography Survey along SSK Drive for feasibility study on temporary widening (approx. 870m)
- Survey of site area occupied by CEDD Contract Contract No. NL/2020/07

## 3. Responsibilities for Activities described within Method Statement

CSHK is responsible to inspect and carry out the construction works. The responsible persons are listed below and be responsible for the activities:

| Company | Name | Position | Contact No. |
| ------- | ---- | -------- | ----------- |
| CSHK | Howard Siu | Construction Manager | 9495 9399 |
| CSHK | CF Chan | Construction Manager | 9668 7888 |
| CSHK | Anthony He | Assistant Construction Manager | 6822 1099 |
| CSHK | Kanson Woo | Senior Engineer | 6289 0390 |
| CSHK | Andrew Lo | Graduate Engineer | 6764 6649 |
| CSHK | Leung Kwok Fung | Safety Manager | 9683 3846 |
| CSHK | Ernest Young | Assistant Safety Officer | 6055 5319 |
| CSHK | Lau Yu Tat | Surveyor | 9419 0614 |
| CSHK | Cheung Siu Kei | Superintendent | 9080 3168 |
| Build King | Vincent Kwan | Deputy Site Agent | 9833 1313 |

(a) **Construction Manager**  
Responsible for overall administration, monitoring, controlling progress and quality of works in a safe manner.

(b) **Engineer**  
Responsible for developing works procedures, controlling progress and quality of works in a safe manner. They also have to implement safety at works area for workers via guidance from safety officers.

(c) **Safety Manager/ Safety Officer**  
Responsible for assessing working conditions of work areas in safety means. To prepare risk assessment before works, enforce safety works practice and environment in the workplace and work site.

(d) **Surveyor**  
Responsible for Topography Survey along the SSK Drive, survey result recording, and inspection records analysis.

(e) **Site Supervisor/Site Foreman**  
Person in charge of the work in the works areas, which are located at various positions of site. Site Supervisor/Site Foreman is also responsible in implementing works control checklist.

## 4. Programme and Working Hours

The method statement is applicable for the topography survey along the SSK Drive. The survey is tentatively scheduled in Mid-January 2024. The general working hours will be from 08:00 - 18:00 daily, from Monday to Saturday and expected to be completed within a week.

## 5. Plant, Equipment & Material

All equipment will be inspected prior to the mobilization on site to ensure that they are in good working condition and comply with the current regulations. The major equipment will be deployed to carry out the works are as follow:
- Leica Total Station TS15A or equivalent. (Accuracy 1” & 1mm+1.5ppm)
- Tripod and prism pole
- Leica Digital Level DNA03 or equivalent. (Accuracy data in Appendix C)
- Barcode invar staff
- Target set and prism
- Survey nail with marker ring
- Spray Paint
- Red cloth
- Wood peg and nail

## 6. Works Methodology

For survey activities carrying out for the project, access arrangement through coordination with CEDD Contractor will be arranged to ensure safety for survey work. The layout plan for survey works area are shown in Appendix A.

### 6.1 Accuracy of Survey Control

| Horizontal Control Network | Requirement |
| -------------------------- | ----------- |
| Accuracy | 1:30,000 |
| Origin | MTRCL Master Control Station |
| Traverse Leg | Distance to adjacent primary control stations established to be between 300m to 1000m |

| Vertical Control Network | Requirement |
| ------------------------ | ----------- |
| Accuracy | Levelling route shorter than 1km: +/- 1mm VN (where N is number of set-up) Levelling route over 1km: +/- 4mm VK (where K is in Kilometres) |
| Origin | MTRCL master control stations and benchmarks |
| Traverse Leg | Distance to adjacent Benchmarks established to be no more than 500m |

### 6.2 Topography Survey

Topography Survey along SSK Drive for the Feasibility Study on Temporary Widening will be carried out along the SSK Drive (approx. 870m) with the planned extent shown in Appendix A. In which, the as-built road profile, existing ground level, location of existing features shall be recorded by survey team. The information will be used to determine the extent of temporary widening of SSK Drive.

- **Figure 6.2-1** Existing ELS Works by CEDD Contract Contract No. NL/2020/07 at SSK Drive
- **Figure 6.2-2** Site Container Area by CEDD Contract Contract No. NL/2020/07 at SSK Drive
- **Figure 6.2-3** Material Stockpiling Area by CEDD Contract Contract No. NL/2020/07 at SSK Drive

Topography Survey at SSK Drive will be carried out and the drawings at a scale of 1:500 with reference to G1.9.1 of the General Specification. For the plotting scale 1:500. A quick check of survey instruments before the field work will be carried out. At the starting and end of the topography survey process, two or more back-sight reference controls will be used to ensure that the control stations and entire survey process are stable and trustworthy. The topography survey plan should record all original landforms, topography, levels and etc., it also locates or confirms the details and locations of all utility services, carriageway, roadsides furniture, buildings, structures and any construction work adjacent to the site. Survey control stations for topography survey shall be established by traverse and comply with standard of accuracy as required in General Specification. Clear field notes are required and on-site verification will be carried out to ensure coverage and correctness, it will be assisted by field booking with feature code with reference to CADD Manual, and the drawing sketches on site. All data will be recorded in data logger.

## 7. Safety

(a) Coordination between CEDD Contract Contract No. NL/2020/07 will be arranged prior to arrangement of Topography Survey, including but not limited to the extent of survey work and working period.

(b) All workers shall be equipped with reflective vests and safety helmets during operation. All workers must go through a briefing by the Construction Manager / Engineer / Safety Officer/Safety Supervisor before commencement of any works.

(c) A pre-meeting will be arranged before commencement of the work among Survey Team, Construction Team and Safety Team to brief the nature of works, the safety aspects and the necessary safety requirements as identified in the Risk Assessment in Appendix D.

(d) Safety helmets fitted with chin straps must be worn within the site, safety boots, hearing protectors (if needed), high visibility jackets/ sashes, reflective vests, goggles, gloves and full body harnesses for work at height will be provided to all staff working on site. Plastic barriers and reflective traffic cones will be prepared prior to work commencement to demarcate the working area.

(e) Particular care needs to be taken when working on or near SSK Drive. Plastic barriers and reflective traffic cones will be prepared prior to work commencement to demarcate the working area.

(f) Any emergency situation shall be reported to site supervisors (i.e. Construction Manager/Engineer/ Foreman, etc.) and Safety Department for prompt response. The emergency contact list is shown in Section 3. The risk for the works shall be assessed and the Risk Assessment Analysis is shown in Appendix D.

## 8. Environmental

The following mitigation measures will be followed:

(a) **Noise**  
General works shall be carried out during normal working hours (08:00 to 18:00). However, should the progress demand for the works to be undertaken from 19:00 to 07:00 next day or on public holidays, construction noise permit shall be obtained as necessary.

(b) **Trees**  
The risk of causing damage to existing trees during survey works is low. If any survey will affect the existing tree, construction team will be informed immediately for resolving.

## 9. Quality Control

Refer to Appendix B for Inspection and Test Plan. Construction works shall be fully complied with Quality Plan. For work activity which is classified as "Quality Hold Point", no subsequent work can be started unless the former work activity was inspected and accepted by MTR's inspectorate.

## 10. Appendices

- **A.** Layout plan and typical section of works
- **B.** Inspection and Test Plan (ITP)
- **C.** Technical Data of Equipment
- **D.** Risk Assessment
