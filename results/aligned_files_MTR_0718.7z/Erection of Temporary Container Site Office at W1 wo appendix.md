# Method Statement Report

## 1. Introduction (Overview of the operation/works)

After handover work areas to CSHK, we will erect the container site office at W11, in order to provide workstations for front line staffs such as engineers, foreman, land surveyors and workers. Also, the temporary container site office will provide the storage area, toilet and shower area, canteen area for the staffs and workers. Not store any oil fuel at the container. This method statement descripts the method and sequence of erection of container site office.

## 2. Details of Sub-Contractor/Specialist Sub-Contractor

The works will be carried out by our direct labour and supervise by our front-line staff such as foreman and engineer. We will also provide the full-time CP (Railway Safety Rules and Requirements) on site, appoint 1 CP(T) for 20 workers work at same work area. All workers should possess the qualification Railway Safety training (RSI). If necessary, CP will be arranged at each works areas. Besides, WPIC will be assigned to supervise the construction works at each work site.

## 3. Responsibilities for Activities described within Method Statement

CSHK is responsible to inspect and carry out the construction works. The following persons, as listed in the table below, will attend the specific tool-box talk and be responsible for the activities:

| Company | Name           | Position                   |
|---------|----------------|----------------------------|
| CSHK    | Vincent Li     | Construction Manager       |
| CSHK    | Nana Chung     | Assistant Construction Manager |
| CSHK    | David Lam      | Senior Engineer            |
| CSHK    | Johnson Chung  | Senior Engineer            |
| CSHK    | Kingsley Zhao  | Assistant Engineer         |
| CSHK    | Li Man Hin     | Graduate Engineer          |
| CSHK    | Cheung Siu Kei | Superintendent (WPIC)      |
| CSHK    | Wong Yu Fung   | Senior Foreman             |
| CSHK    | Ng Ho Lun      | Senior Foreman             |
| CSHK    | Pun Chi Ho     | Foreman                    |
| CSHK    | Luk Si Sun     | Mechanic & authorized electrician |

## 4. Programme and Working Hours (Start & finish date of operation/works)

The works will be commenced on end Jan 2024, target complete on mid Mar 2024. The works will be carried on day time from 08:00 am to 07:00 pm, Monday to Saturday. The works shall obtain Depot YM’s prior permission. ETMS shall be provided & approved, and the CP shall obtain DOC permission to start the works.

## 5. Resources, Plant, Equipment & Material (Identify type, model and specification of MAJOR plant & equipment)

### Plant and Equipment Condition

All plants and equipment will be inspected prior to the mobilization on site to ensure that they are in good working condition and comply with the current regulations. All statutory forms/certificates of Lifting Appliances (LA) and Lifting Gear (LG) must be valid. Before operation of the plant, CSHK will arrange a plant inspection with MTR CWBU inspector, if they are in good working condition, CSHK will submit the plant permit and permit to lift to the plant. The major plants and equipment will be deployed to carry out the works are as follow:

| Plant / Equipment         | Quantity |
|---------------------------|----------|
| Crane Lorry / Lorry       | 1        |
| Lorry                     | 2        |
| 3T Backhoe                | 2        |
| Grab Lorry                | 1        |
| Generator (QPME)          | 2        |
| Step Platform/Cherry Picker | 1      |

### Manpower

| Manpower         | Quantity |
|------------------|----------|
| General Labour   | 8        |
| Rigger           | 4        |
| Driver           | 1        |
| Operator         | 2        |
| Fire Warden      | 1        |

### Lifting Arrangement

- Loading/Unloading Zone
- Lifting Plan
  - 45 tons Crane Lorry
  - 3T Backhoe: 10m radius: 4.135 ton *0.8 safety factor=3.3 ton > 3 tons = OK
  - 2.2T Container: 10m radius: 4.135 ton *0.8 safety factor=3.3 ton > 2.2 tons = OK

### Lifting the Container

- Step platform for hang up and removal of lifting gear rigger
- Lifting Supervisor
- Driver/Operator
- CP(T)

### Works Areas W11

- For some containers, the workers will not work on the roof of the container because there are four lifting holes at the four corners of the container, and the workers will stand on the step platform for the hang up and removal of the lifting gear.
- For some containers, the workers will work on the roof of the container.
- The workers will go to the roof of the container by using the step platform/cherry picker.
- During the erection of containers, Steel posts with Safety wire will be fixed on the corners of the container to guaranty the workers’ safety, and the workers will be also wearing the Full Body Safety Harness, and equipped with a self-retracting lifeline that hang on the safety wire.
- No part of the crane lorry will work beyond the water filled barrier and the maximum lifting load shall be <80% of SWL.
- Load of lifting gears must be counted as part of the lifting load.
- Outrigger of the crane lorry shall be full extended before lifting works.

## 6. Traffic and Security Management

### Contractor Vehicle Arrangement

- Pre-registration of the car plate and driver information will be provided to the Security Operation Centre (SOC) to obtain the entry permit through the west gate.
- Contractor Vehicle should display the entry permit, a label with the wordings '1701 contract vehicle', and the destination (e.g., W11) and location plan on the windscreen.
- CSHK will report the total number of workers In/Out Records to SOC Daily.
- Reregistered vehicles shall not carry unauthorized/unregistered passengers.
- Before entering the west gate, CSHK, CP(T) will measure the height of vehicle, ensure the height is within 4m.
- After entering the west gate, the Contractor Vehicle will be accompanied by the escort vehicle with CP(T).
- When accessing west level crossing, CPT of escort car shall communicate with DCC in order to get permission to drive across the level crossing. CPT shall inform DYM when vehicles passing through the yellow line underneath the height restriction gauge, and within the double white zone.
- No vehicle Reversing is allowed.
- Before left W11, CSHK, CP(T) will measure the height of vehicle again, ensure the height within 4m to access the west gate level cross.
- No vehicle over 4m high and below 4.5m high is allowed unless a Permit-to-Move is issued by CWBU to DCC for approval. Vehicle height measurements/checks shall be conducted by CP(T)s before entering depot areas and passing thru the west level crossing.
- Permitted vehicles must be driven through level crossings at a speed of not over 10kph.
- All vehicles, except shuttle bus for staff and workers, shall not be entered from West gate from 7:30am to 8:30am in order to minimize the track jam.
- All security guard shall have RSI training if they are works at the OA area.

### Worker Verification

- All workers will be picked up at designated area such as Tung Chung Station.
- During boarding the shuttle bus, hand-held facial recognition will be performed to verify the worker's qualification.
- The facial recognition system will check if the person has passed the RSI and possesses a green card.
- List of workers shall be submitted for MTR for registration before starting of works, the list shall be updated weekly and available for MTR as requested.
- Uniform and Safety Equipment: All workers shall wear PPE and the standard uniform and safety helmet for easy recognition by security guards and YM.

## 7. Construction Methods / Construction Sequence Drawings

### Preparation

- Prior to commence the works, CSHK will provide the information to MTR CWBU Inspector, in order to submit the work notice to SOC/DCC every Friday. The associated MS/EDOC information (Title, reference no. etc) shall be clearly written down in the work notice for easy reference.

### Training for the Workers

- Prior to start any physical works, CSHK foreman/engineer will provide a briefing to all workers, inform them the rules of working at SHD, traffic and security management arrangement, method for the construction work, safety control measure, quality control and environmental issues. All workers can smoke at the demarcated smoke area only.

### Welfare facilities

- Set up the rest area and portable toilet at W11.
- Toilet disposal will be disposed with a septic tanker truck.

### Construction Works - Site Clearance

- Identify the existing MTR facilities near or into construction site, such as manhole cover. Apply protections (To be agreed with MTR) to all the identified MTR facilities and take photographic records before any work commencement.
- Carry out the condition survey and photographic record.
- Put the labelled cone on manhole cover on site in order to avoid the water filled barrier covered the manhole cover.
- CSHK will carry out UU detection (Method Statement of UU detection to be submitted separately).
- If there don’t have any UU at the Container Site Office area, CS will carry out the site clearance works.
- Fence off the temporary container site office by water filled barrier with top panel. (Install a transparent panel every 4 white colour panels) The top panel will be removed when in typhoon signal no.3 or above.
- The site clearance works carry out by 3T backhoe, include remove the garbage and weeds.
- To remove the garbage, CS will provide the information to MTR CWBU inspector to fill in the material transfer record sheet to the SOC.
- Fire fighting equipment must be provided on site.
- CSHK will arrange the grab lorry to transport the garbage to the waste disposal facilities daily.
- For the ease of identification, company name will be stick or printed on the water filled barrier.

### Construction Works – Laying Blinding Concrete for Temporary Container Site Office

- CSHK will place the 150mm 20/20 concrete blinding with mesh for the temporary container site office. The concrete will come from concrete factory, delivery by concrete truck, 3T backhoe will assist to lay the concrete.

### Construction Works – Erect the Temporary Container Site Office

- Erect the container site office on the concrete blinding.
- Label the layout plan and emergency contact list on the container.
- Erect the chain link fence and access gate to enclose the temporary container site office, then remove the water filled barrier.
- Install earthing system (refer to the detail below) to the container and power supply.
- Connect the power supply (Generator) to all container site office.
- Air conditioner will be provide for container. Fire extinguisher will be placed inside the container since there is no fire detection system.
- Connect the water supply (Temporary will be Depot Water Point) to the toilet.
- CSHK will construct the 100mm dia. U-channel around the container site office as the temporary drainage, the water will be connected to the temporary catch pits and wetset, then discharge to the designated discharge point. And the discharge points should be agreed with depot and CWBU.

#### U-Channel detail

#### Proposed earthing details

## 8. Safety (Risk Assessments)

Risk assessment and Job hazard analysis attached in Appendix A has been prepared for all general activities. Specific safety procedures and precautions have been developed for all site operatives to follow. The Construction Team Leader together with the RSO, will supervise the implementation and make adjustment according to the actual site operations, in order to maintain a safe and amicable working environment.

## 9. Environmental (Environmental aspect & impact identification as well as mitigation measures)

The following mitigation measures will be followed:

- General works shall be carried out during normal hours form 08:00 am to 07:00 pm. No works will be carried out after 07:00 pm on Sunday or public holiday without approval construction noise permit.
- ULSD diesel will be used in all PME.
- Plant with QPME label will be employ, if available.
- All chemicals will be placed on drip tray.
- Water spray will be carried out during the work to prevent dust generation.
- Switch off the power of container once get off work.

### Smoke Arrangement

- All workers should possess the qualification Railway Safety training (RSI), and can only smoke at the smoking area that demarcated by CSHK.

### Facilities for Smoke Area

- Cigarette Butt Receptacle
- Fire Extinguisher
- Sand Bucket 防火沙

## 10. Appendices (Identify and include additional information in the submission package)

- Appendix A- Risk assessment
- Appendix B - Catalogue for Equipment
- Appendix C-Layout Plan
- Appendix D-Lifting Plan
- Appendix E- Emergency Contact List
- Appendix F-ITP (N/A)
